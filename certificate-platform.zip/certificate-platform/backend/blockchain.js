// backend/blockchain.js
const Web3 = require('web3');

// 🔹 Remix VM  (محلي مؤقت)
const web3 = new Web3('http://127.0.0.1:8545');

// 🔹 عنوان العقد الذكي من Remix
const contractAddress = '0xd8b934580fcE35a11B58C6D73aDeE468a2833fa8';

// 🔹 ABI 
const abi = [
	{
		"inputs": [
			{ "internalType": "string", "name": "id", "type": "string" },
			{ "internalType": "string", "name": "name", "type": "string" },
			{ "internalType": "string", "name": "issuer", "type": "string" },
			{ "internalType": "string", "name": "hash", "type": "string" }
		],
		"name": "issueCertificate",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{ "internalType": "string", "name": "", "type": "string" }
		],
		"name": "certificates",
		"outputs": [
			{ "internalType": "string", "name": "name", "type": "string" },
			{ "internalType": "string", "name": "issuer", "type": "string" },
			{ "internalType": "string", "name": "hash", "type": "string" },
			{ "internalType": "bool", "name": "valid", "type": "bool" }
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{ "internalType": "string", "name": "id", "type": "string" }
		],
		"name": "verifyCertificate",
		"outputs": [
			{ "internalType": "bool", "name": "", "type": "bool" }
		],
		"stateMutability": "view",
		"type": "function"
	}
];

// إنشاء العقد من العنوان والـ ABI
const contract = new web3.eth.Contract(abi, contractAddress);

module.exports = { web3, contract };
