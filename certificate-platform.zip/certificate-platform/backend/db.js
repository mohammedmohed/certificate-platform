const { MongoClient } = require('mongodb');

const _uri = "mongodb+srv://mohed:mohed2002@cluster0.nk1mx6z.mongodb.net/finalProject?retryWrites=true&w=majority&appName=Cluster0";

const dbConnection =  (nameCollection, cb) => {
    MongoClient.connect(_uri)
    .then(async (client)=>{
        const db = client.db("finalProject").collection(nameCollection);
        await cb(db);
        client.close();
    })
    .catch((err)=>{
        console.log(err.message);
    });    
};

module.exports = dbConnection;
