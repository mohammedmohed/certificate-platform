const mongoose = require('mongoose');

const certificateSchema = new mongoose.Schema({
  title: String,
  description: String,
  issuedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  issuedTo: String,
  issueDate: Date,
  certificateFile: String, // مسار الصورة
  verified: { type: Boolean, default: false }
});

module.exports = mongoose.model('Certificate', certificateSchema);
