const express = require('express');
const router = express.Router();
const { web3, contract } = require('../blockchain');



router.post('/issue', async (req, res) => {
  try {
    const { id, name, issuer, hash } = req.body;
    const accounts = await web3.eth.getAccounts();

    await contract.methods.issueCertificate(id, name, issuer, hash)
      .send({ from: accounts[0], gas: 3000000 });

    res.json({ message: 'Certificate issued successfully!' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error issuing certificate' });
  }
});

// التحقق من شهادة
router.get('/verify/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const valid = await contract.methods.verifyCertificate(id).call();
    res.json({ id, valid });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error verifying certificate' });
  }
});

module.exports = router;
