const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const dbConnection = require('../db'); // ملف db.js

// ---------------- CORS (إذا لم يتم تفعيله في server.js) ----------------
const cors = require('cors');
router.use(cors());

// ---------------- REGISTER ----------------
router.post('/register', async (req, res) => {
  const { name, email, password } = req.body;
  try {
    const hashed = await bcrypt.hash(password, 10);

    dbConnection('users', async (usersCollection) => {
      const existingUser = await usersCollection.findOne({ email });
      if (existingUser) {
        return res.status(400).json({ message: 'Email already exists' });
      }

      await usersCollection.insertOne({ name, email, password: hashed, role: 'user' });
      res.json({ message: 'User registered successfully' });
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// ---------------- LOGIN ----------------
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    dbConnection('users', async (usersCollection) => {
      const user = await usersCollection.findOne({ email });
      if (!user) return res.status(400).json({ message: 'User not found' });

      const valid = await bcrypt.compare(password, user.password);
      if (!valid) return res.status(400).json({ message: 'Invalid password' });

      const token = jwt.sign(
        { id: user._id.toString(), role: user.role },
        'secretkey',
        { expiresIn: '1d' }
      );

      res.json({ token, user: { name: user.name, email: user.email, role: user.role } });
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
