const express = require('express');
const router = express.Router();
const Certificate = require('../models/Certificate');
const dbConnection = require('../db');

// عرض كل الشهادات
router.get('/certificates', async (req, res) => {
  const certs = await Certificate.find();
  res.json(certs);
});

// اعتماد شهادة
router.put('/verify/:id', async (req, res) => {
  const cert = await Certificate.findByIdAndUpdate(req.params.id, { verified: true }, { new: true });
  res.json(cert);
});
router.get('/users', async (req, res) => {
  dbConnection('users', async (usersCollection) => {
    const users = await usersCollection.find({}).toArray();
    res.json(users);
  });
});
router.put('/users/:id', async (req, res) => {
  const { id } = req.params;
  const { name, email, role, active } = req.body;
  const { ObjectId } = require('mongodb');

  dbConnection('users', async (usersCollection) => {
    try {
      const result = await usersCollection.updateOne(
        { _id: new ObjectId(id) },
        { $set: { name, email, role, active } }
      );
      if (result.matchedCount === 0) return res.status(404).json({ message: 'User not found' });
      res.json({ message: 'User updated successfully' });
    } catch (err) {
      console.error('❌ Error updating user:', err);
      res.status(500).json({ message: 'Error updating user' });
    }
  });
});
router.delete('/users/:id', async (req, res) => {
  const { id } = req.params;
  const { ObjectId } = require('mongodb');

  dbConnection('users', async (usersCollection) => {
    try {
      const result = await usersCollection.deleteOne({ _id: new ObjectId(id) });
      if (result.deletedCount === 0) return res.status(404).json({ message: 'User not found' });
      res.json({ message: 'User deleted successfully' });
    } catch (err) {
      console.error('❌ Error deleting user:', err);
      res.status(500).json({ message: 'Error deleting user' });
    }
  });
});


module.exports = router;
