const express = require('express');
const router = express.Router();
const multer = require('multer');
const dbConnection = require('../db');
const path = require('path');
const crypto = require('crypto');
const { web3, contract } = require('../blockchain');
const fs = require('fs');

const uploadDir = path.join(__dirname, '../uploads'); // مسار داخل backend

if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}

// إعداد التخزين للملفات
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir); // استخدام المسار المطلق
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});
const upload = multer({ storage });

// 🟢 رفع شهادة جديدة فقط (بدون توثيق)
router.post('/upload', upload.single('certificateFile'), (req, res) => {
  const { title, description, issuedBy, issuedTo, userId } = req.body;
  const fileName = req.file ? req.file.filename : null;

  if (!fileName) return res.status(400).json({ message: 'Certificate file is required' });

  dbConnection('certificates', async (certsCollection) => {
    try {
      const hash = crypto.createHash('sha256')
        .update(title + issuedBy + issuedTo + Date.now())
        .digest('hex');

      const result = await certsCollection.insertOne({
        title,
        description,
        issuedBy,
        issuedTo,
        userId: userId || null, 
        issueDate: new Date(),
        certificateFile: fileName,
        hash,
        verified: false
      });

      res.json({ message: 'Certificate uploaded successfully!', certificateId: result.insertedId });
    } catch (err) {
      console.error('❌ Error uploading certificate:', err);
      res.status(500).json({ message: 'Error uploading certificate' });
    }
  });
});

// 🟢 الحصول على جميع الشهادات
router.get('/', (req, res) => {
  dbConnection('certificates', async (certsCollection) => {
    const certs = await certsCollection.find({}).toArray();
    res.json(certs);
  });
});

// 🟢 جلب شهادات مستخدم معين
router.get('/user/:userId', (req, res) => {
  const { userId } = req.params;
  dbConnection('certificates', async (certsCollection) => {
    const certs = await certsCollection.find({ userId }).toArray();
    res.json(certs);
  });
});

router.post('/verify/:id', async (req, res) => {
  const { id } = req.params;
  const { ObjectId } = require('mongodb');

  dbConnection('certificates', async (certsCollection) => {
    try {
      const cert = await certsCollection.findOne({ _id: new ObjectId(id) });
      if (!cert) return res.status(404).json({ message: 'Certificate not found' });

      if (!cert.title || !cert.issuedBy || !cert.hash) {
        return res.status(400).json({ message: 'Certificate data incomplete. Cannot verify on blockchain.' });
      }

      await certsCollection.updateOne(
        { _id: new ObjectId(id) },
        { $set: { verified: true } }
      );

      const accounts = await web3.eth.getAccounts();
      await contract.methods
        .issueCertificate(id.toString(), cert.title, cert.issuedBy, cert.hash)
        .send({ from: accounts[0], gas: 3000000 });

      res.json({ message: 'Certificate verified and recorded on blockchain successfully!' });
    } catch (err) {
      console.error('❌ Error verifying certificate:', err);
      res.status(500).json({ message: 'Error verifying certificate' });
    }
  });
});

// 🟢 التحقق من شهادة عبر البلوك تشين
router.get('/verify/:id/status', async (req, res) => {
  const { id } = req.params;
  const { ObjectId } = require('mongodb');

  dbConnection('certificates', async (certsCollection) => {
    try {
      const cert = await certsCollection.findOne({ _id: new ObjectId(id) });
      if (!cert) return res.status(404).json({ message: 'Certificate not found' });

      const valid = await contract.methods.verifyCertificate(id).call();

      res.json({
        ...cert,
        blockchainVerified: valid
      });
    } catch (err) {
      console.error('❌ Error verifying certificate status:', err);
      res.status(500).json({ message: 'Blockchain verification error' });
    }
  });
});

// 🟢 البحث عن شهادة بالاسم أو الشخص
router.get('/search', async (req, res) => {
  const { query } = req.query;
  if (!query) return res.status(400).json({ message: 'Search query is required' });

  dbConnection('certificates', async (certsCollection) => {
    const cert = await certsCollection.findOne({
      $or: [
        { title: { $regex: query, $options: 'i' } },
        { issuedTo: { $regex: query, $options: 'i' } }
      ]
    });

    if (!cert) return res.status(404).json({ message: 'Certificate not found' });
    res.json(cert);
  });
});

// 🟢 حذف شهادة (Admin فقط)
router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  const { ObjectId } = require('mongodb');

  dbConnection('certificates', async (certsCollection) => {
    try {
      const result = await certsCollection.deleteOne({ _id: new ObjectId(id) });
      if (result.deletedCount === 0) return res.status(404).json({ message: 'Certificate not found' });
      res.json({ message: 'Certificate deleted successfully' });
    } catch (err) {
      console.error('❌ Error deleting certificate:', err);
      res.status(500).json({ message: 'Error deleting certificate' });
    }
  });
});

// 🟢 تعديل شهادة (Admin فقط)
router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { title, description, issuedBy, issuedTo, verified, userId } = req.body;
  const { ObjectId } = require('mongodb');

  dbConnection('certificates', async (certsCollection) => {
    try {
      const result = await certsCollection.updateOne(
        { _id: new ObjectId(id) },
        { $set: { title, description, issuedBy, issuedTo, verified, userId } }
      );
      if (result.matchedCount === 0) return res.status(404).json({ message: 'Certificate not found' });
      res.json({ message: 'Certificate updated successfully!' });
    } catch (err) {
      console.error('❌ Error updating certificate:', err);
      res.status(500).json({ message: 'Error updating certificate' });
    }
  });
});

// 🟢 جلب شهادة واحدة حسب ID
router.get('/:id', async (req, res) => {
  const { id } = req.params;
  const { ObjectId } = require('mongodb');

  dbConnection('certificates', async (certsCollection) => {
    try {
      const cert = await certsCollection.findOne({ _id: new ObjectId(id) });
      if (!cert) return res.status(404).json({ message: 'Certificate not found' });
      res.json(cert);
    } catch (err) {
      console.error('❌ Error fetching certificate:', err);
      res.status(500).json({ message: 'Error fetching certificate' });
    }
  });
});
//  جلب شهادات المستخدم الحالي (باستخدام التوكن)
const jwt = require('jsonwebtoken');

router.get('/my', async (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(401).json({ message: 'Authorization header missing' });

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, 'secretkey');
    const userId = decoded.id;

    dbConnection('certificates', async (certsCollection) => {
      const certs = await certsCollection.find({ userId }).toArray();
      res.json(certs);
    });
  } catch (err) {
    console.error('❌ Error verifying token or fetching user certificates:', err);
    res.status(403).json({ message: 'Invalid or expired token' });
  }
});

module.exports = router;
