const certApi = "http://localhost:5000/api/certificates";

document.getElementById('uploadForm')?.addEventListener('submit', async e => {
  e.preventDefault();
  const formData = new FormData();
  formData.append('title', title.value);
  formData.append('issuedTo', issuedTo.value);
  formData.append('description', description.value);
  formData.append('certificateFile', certificateFile.files[0]);
  formData.append('issuedBy', '675ad15e3f47b5f5b0a12345'); // استبدلها بـ id حقيقي

  const res = await fetch(`${certApi}/upload`, {
    method: 'POST',
    body: formData
  });
  alert((await res.json()).message);
});

document.getElementById('verifyBtn')?.addEventListener('click', async () => {
  const res = await fetch(`${certApi}/verify/${certId.value}`);
  const cert = await res.json();
  if (cert.title)
    document.getElementById('result').innerHTML = `
      <p>Title: ${cert.title}</p>
      <p>Issued To: ${cert.issuedTo}</p>
      <p>Issued By: ${cert.issuedBy}</p>
      <img src="http://localhost:5000/uploads/${cert.certificateFile}" width="200">
    `;
  else alert(cert.message);
});
