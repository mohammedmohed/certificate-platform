const form = document.getElementById('uploadForm');
const uploadMessage = document.getElementById('uploadMessage');

form.addEventListener('submit', async (e) => {
  e.preventDefault();

  const formData = new FormData();
  formData.append('title', document.getElementById('certTitle').value);
  formData.append('description', document.getElementById('certDescription').value);
  formData.append('issuedBy', document.getElementById('certIssuer').value);
  formData.append('issuedTo', document.getElementById('certRecipient').value);
  formData.append('certificateFile', document.getElementById('certFile').files[0]);

  // الحصول على التوكن من localStorage
  const token = localStorage.getItem('token');

  try {
    const res = await fetch('http://localhost:5000/api/certificates/upload', {
      method: 'POST',
      body: formData,
      headers: {
        'Authorization': `Bearer ${token}`  // إضافة التوكن
      }
    });

    const data = await res.json();
    if (res.ok) {
      uploadMessage.innerText = data.message;
      form.reset();
    } else {
      uploadMessage.innerText = data.message || 'Server error!';
    }
  } catch (err) {
    console.error(err);
    uploadMessage.innerText = 'Server error!';
  }
});
