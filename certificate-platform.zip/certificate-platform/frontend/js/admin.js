const certTableBody = document.querySelector('#certificatesTable tbody');
const usersTableBody = document.querySelector('#usersTable tbody');

async function fetchCertificates() {
  try {
    const res = await fetch('http://localhost:5000/api/certificates');
    const certificates = await res.json();
    certTableBody.innerHTML = '';

    certificates.forEach(cert => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><img src="http://localhost:5000/uploads/${cert.certificateFile}" alt="Certificate Image" width="100"></td>
        <td>${cert.title}</td>
        <td>${cert.issuedTo}</td>
        <td>${cert.issuedBy}</td>
        <td>${cert.verified ? 'Verified' : 'Not Verified'}</td>
        <td>
          ${!cert.verified ? `<button onclick="verifyCertificate('${cert._id}')">Verify</button>` : ''}
          <button onclick="editCertificate('${cert._id}')">Edit</button>
          <button onclick="deleteCertificate('${cert._id}')">Delete</button>
        </td>
      `;
      certTableBody.appendChild(tr);
    });
  } catch (err) {
    console.error('Error fetching certificates:', err);
  }
}

async function verifyCertificate(id) {
  if (!confirm('Are you sure you want to verify this certificate?')) return;

  try {
    const res = await fetch(`http://localhost:5000/api/certificates/verify/${id}`, {
      method: 'POST'
    });
    const data = await res.json();
    alert(data.message);
    fetchCertificates();
  } catch (err) {
    console.error('Error verifying certificate:', err);
    alert('An error occurred while verifying the certificate.');
  }
}

function editCertificate(id) {
  window.location.href = `editCertificate.html?id=${id}`;
}

// 🗑️ دالة حذف الشهادة
async function deleteCertificate(id) {
  if (!confirm('Are you sure you want to delete this certificate?')) return;

  try {
    const res = await fetch(`http://localhost:5000/api/certificates/${id}`, {
      method: 'DELETE'
    });
    const data = await res.json();
    alert(data.message || 'Certificate deleted successfully');
    fetchCertificates(); // تحديث الجدول بعد الحذف
  } catch (err) {
    console.error('Error deleting certificate:', err);
    alert('An error occurred while deleting the certificate.');
  }
}

async function fetchUsers() {
  try {
    const res = await fetch('http://localhost:5000/api/admin/users');
    const users = await res.json();
    usersTableBody.innerHTML = '';

    users.forEach(user => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${user.name}</td>
        <td>${user.email}</td>
        <td>${user.role}</td>
        <td>${user.active ? 'Active' : 'Inactive'}</td>
        <td>
          <button onclick="editUser('${user._id}')">Edit</button>
          <button onclick="deleteUser('${user._id}')">Delete</button>
        </td>
      `;
      usersTableBody.appendChild(tr);
    });
  } catch (err) {
    console.error('Error fetching users:', err);
  }
}

function editUser(id) { alert('Edit user ' + id); }
function deleteUser(id) { alert('Delete user ' + id); }

fetchCertificates();
fetchUsers();
