const params = new URLSearchParams(window.location.search);
const certificateId = params.get('id');
const messageEl = document.getElementById('message');

function goBack() {
  window.location.href = 'admin.html';
}

// تحميل بيانات الشهادة
async function loadCertificate() {
  try {
    const res = await fetch(`http://localhost:5000/api/certificates/${certificateId}`);
    if (!res.ok) throw new Error('Failed to load certificate data.');
    const cert = await res.json();

    document.getElementById('title').value = cert.title || '';
    document.getElementById('issuedTo').value = cert.issuedTo || '';
    document.getElementById('issuedBy').value = cert.issuedBy || '';
    document.getElementById('description').value = cert.description || '';
    document.getElementById('verified').value = cert.verified ? 'true' : 'false';
  } catch (err) {
    messageEl.textContent = err.message;
    messageEl.style.color = 'red';
  }
}

loadCertificate();

// حفظ التعديلات
document.getElementById('editCertificateForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    const res = await fetch(`http://localhost:5000/api/certificates/${certificateId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: document.getElementById('title').value,
        issuedTo: document.getElementById('issuedTo').value,
        issuedBy: document.getElementById('issuedBy').value,
        description: document.getElementById('description').value,
        verified: document.getElementById('verified').value === 'true'
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Failed to update certificate.');
    messageEl.textContent = data.message;
    messageEl.style.color = 'green';
  } catch (err) {
    messageEl.textContent = err.message;
    messageEl.style.color = 'red';
  }
});
